class CoffeeMachine:
    def __init__(self):
        self.milk = 1000
        self.coffee = 1000
        self.sugar = 1000
    
    def make_coffee(self, milk, coffee, sugar):
        if self.milk >= milk and self.coffee >= coffee and self.sugar >= sugar:
            self.__subtract_milk(milk)
            self.__subtract_coffee(coffee)
            self.__subtract_sugar(sugar)
            print("Процесс приготовления кофе завершен!")
        else:
            if self.milk - milk < 0:
                print(f'Пополните запасы молока на {milk - self.milk}мл.')
            if self.coffee - coffee < 0:
                print(f'Пополните запасы кофе на {coffee - self.coffee}грамм.')
            if self.sugar - sugar < 0:
                print(f'Пополните запасы сахара на {sugar - self.sugar}грамм.')


    def __subtract_milk(self, milk):
        self.milk -= milk
    
    def __subtract_coffee(self, coffee):
        self.coffee -= coffee

    def __subtract_sugar(self, sugar):
        self.sugar -= sugar

def main():
    lavazza = CoffeeMachine()
    lavazza.make_coffee(200, 200, 200)
    lavazza.make_coffee(1001, 1001, 1001)

if __name__ == '__main__':
    main()