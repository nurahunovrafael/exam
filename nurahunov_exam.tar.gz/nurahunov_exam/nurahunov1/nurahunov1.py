def main():
	f = open("air.txt", "r")
	contents = f.read()
	contents = contents.replace("\n", "").replace(" ", "").replace(".", "").replace(",", "")
	dict = {}
	maxCount = 0
	maxSymbol = ''

	for letter in contents: 
		if letter not in dict:
			dict[letter] = 0

		dict[letter] += 1

		if maxCount < dict[letter] :
			maxCount = dict[letter]
			maxSymbol = letter

	print(dict)
	print('{}: {}'.format(maxSymbol, dict[maxSymbol]))
	
if __name__== "__main__":
	main()