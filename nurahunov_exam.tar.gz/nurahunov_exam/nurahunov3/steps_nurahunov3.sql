CREATE DATABASE IT_company;

SHOW DATABASES;

USE IT_company;

CREATE TABLE project_managers (
id int not null auto_increment primary key,
name VARCHAR(50) NOT NULL,
surname VARCHAR(50) NOT NULL,
gender VARCHAR(6) NOT NULL,
birth DATE NOT NULL)
ENGINE=InnoDB;

SELECT @@default_storage_engine;

CREATE TABLE developers (
id int not null auto_increment primary key,
name varchar(50) not null,
surname varchar(50) not null,
id_project_managers int not null,
gender VARCHAR(6) NOT NULL,
constraint project_manager_developers_fk
foreign key (id_project_managers)
references project_managers(id))
ENGINE=InnoDB;

CREATE TABLE notebook (
id int not null auto_increment PRIMARY KEY,
developers_id int not null UNIQUE,
title varchar(100) not null,
foreign key (developers_id)
references developers(id))
ENGINE=InnoDB;

CREATE TABLE projects (
id int not null auto_increment PRIMARY KEY,
p_title varchar(255) not null)
ENGINE=InnoDB;

CREATE TABLE developers_projects (
id int not null auto_increment PRIMARY KEY,
id_developers int not null,
id_projects int not null,
foreign key (id_developers)
references developers(id)
on delete no action
on update no action,
foreign key (id_projects)
references projects(id)
on delete no action
on update no action)
ENGINE=InnoDB;


INSERT INTO project_managers (id, name, surname, gender, birth)
VALUES
(NULL, 'Ilon', 'Musk', 'Male', '1990-1-5'),
(NULL, 'Pavel', 'Morozov', 'Male', '1997-1-3'),
(NULL, 'Anastassiya', 'CCCC', 'Female', '1994-12-31');


ALTER TABLE developers
ADD birth DATE NOT NULL;

INSERT INTO developers (id, name, surname, id_project_managers, gender, birth)
VALUES
(NULL, 'Aziz', 'Bakaev', '1', 'Male', '1989-1-5'),
(NULL, 'Artur', 'Ant', '1', 'Male', '2000-1-3'),
(NULL, 'Rita', 'Nosina', '2', 'Female', '1997-2-20'),
(NULL, 'Alex', 'Linker', '2', 'Male', '1994-1-5'),
(NULL, 'Pavel', 'Kim', '3', 'Male', '1988-1-3'),
(NULL, 'Anya', 'Fix', '2', 'Female', '1996-12-31');

INSERT INTO notebook (id, title, developers_id)
VALUES
(NULL, 'Dell_3590', 10),
(NULL, 'MacBook_pro', 11),
(NULL, 'MacBook_air', 12),
(NULL, 'HP_123r', 13),
(NULL, 'Asus_6788', 14),
(NULL, 'Dell_3355', 15);

INSERT INTO project_managers (id, name, surname, gender, birth)
VALUES
(NULL, 'Sooronbai', 'Soke','Male', '1958-11-16');


INSERT INTO projects (id, p_title)
VALUES
(NULL, 'Project1'),
(NULL, 'Project2'),
(NULL, 'Project3'),
(NULL, 'Project4');

INSERT INTO developers_projects (id, id_developers, id_projects)
VALUES
(NULL, 10,1),
(NULL, 11,1),
(NULL, 12,2),
(NULL, 13,2),
(NULL, 14,3),
(NULL, 15,3),
(NULL, 10,2),
(NULL, 11,3);







