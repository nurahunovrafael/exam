Select * from developers where year(birth) < 1995 AND gender = 'Male';

SELECT name, surname FROM project_managers
UNION
SELECT name, surname FROM developers;

SELECT *
FROM developers JOIN project_managers
ON developers.id = project_managers.id
WHERE project_managers.name = 'Pavel' ;

Select * from developers_projects;

Select * from developers where year(birth) > 1995-01-01;

SELECT COUNT(gender) FROM developers WHERE gender = 'Male';
SELECT COUNT(gender) FROM developers WHERE gender = 'Female';

